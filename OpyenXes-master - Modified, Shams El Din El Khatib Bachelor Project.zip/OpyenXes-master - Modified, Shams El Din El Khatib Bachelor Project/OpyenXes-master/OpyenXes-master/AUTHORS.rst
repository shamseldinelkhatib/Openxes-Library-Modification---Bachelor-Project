=======
Credits
=======

Development Lead
----------------

* Hernan Valdivieso (The guy who wrote everything!)
* Jorge Munoz-Gama (The mastermind)
* Wai Lam Jonathan Lee 

Contributors
------------

* TKasekamp

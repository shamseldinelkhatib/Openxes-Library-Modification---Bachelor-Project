=======
History
=======

0.1.1 (2017-11-08)
------------------

* First release on PyPI.

0.1.2 (2017-11-08)
-----------------

* Fix missing packages for release.

0.1.3 (2017-11-08)
------------------

* Fixing missing packages in setup.

0.1.4 (2017-11-08)
------------------

* Removed opyenxes module.

0.1.5 (2017-11-08)
------------------

* Fixing missing packages in setup.

0.1.6 (2017-11-09)
------------------

* Making extension.std a module



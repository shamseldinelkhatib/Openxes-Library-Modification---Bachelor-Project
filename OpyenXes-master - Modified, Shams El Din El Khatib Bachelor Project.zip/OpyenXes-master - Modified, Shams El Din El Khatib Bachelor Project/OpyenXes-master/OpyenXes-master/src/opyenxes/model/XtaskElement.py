# -*- coding: utf-8 -*-
"""
Created on Sat Jun  5 15:06:39 2021

@author: Shams
"""


from opyenxes.model.XAttributeMap import XAttributeMap
from opyenxes.model.XElement import XElement

class XtaskElement(XElement):
    """This Class is implemented by 
    all task elements (XtaskTrace & XtaskEvent) of an event log structure.
    It defines that all task elements are attributable

    :param attribute: A `XAttributeMap` with the attribute for this class.
    :type attribute: `XAttributeMap`
    """
    def __init__(self, attribute=XAttributeMap()):
        super(XElement, self).__init__(attribute)



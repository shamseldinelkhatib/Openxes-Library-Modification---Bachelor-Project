# -*- coding: utf-8 -*-
"""
Created on Sun May 30 20:10:17 2021

@author: Shams
"""

from opyenxes.model.XtaskElement import XtaskElement


class XtaskTrace(XtaskElement, list):
    """ A taskTrace is an element of the Extended XES event log structure.
    taskTraces are contained in logs. Any taskTrace is a list of events.
    taskTraces describe sequences of taskEvents, as they have occurred 
    during one execution of a process activity, in their given order.

    :param attributes: Map of attribute for the trace.
    :type attributes: `XAttributeMap`
    """
    def __init__(self, attributes):
        super().__init__(attributes)

    def clone(self):
        """Creates and returns a copy of this object.

        :return: A clone of this instance.
        :rtype: `XTrace`
        """
        clone = XtaskTrace(self.get_attributes().clone())
        for event in self:
            clone.append(event.clone())

        return clone

    def insert_ordered(self, event):
        """Insert the event in an ordered manner, if timestamp information is
         available in this trace.

        :param event: the event to be inserted.
        :type event: `XEvent`
        :return: index of the inserted event.
        :rtype: int
        """
        if len(self) == 0:
            self.append(event)
            return 0
        elif "time:timestamp" not in event.get_attributes():
            self.append(event)
            return len(self) - 1
        else:
            ins_ts = event.get_attributes()["time:timestamp"].get_value()
            for i in range(len(self) - 1, -1, -1):
                my_event = self[i].get_attributes().get("time:timestamp")
                if my_event is None:
                    self.append(event)
                    return len(self) - 1

                ref_ts = my_event.get_value()
                if ins_ts >= ref_ts:
                    self.insert(i + 1, event)
                    return i + 1

            self.insert(0, event)
            return 0

    def append_task(self, p_object):
        """
        Add only a event object in the log.

        :param p_object: a Event object to append for the log
        :type p_object: `XEvent`
        """
        super(XtaskTrace, self).append(p_object)

    def __hash__(self):
        return hash(super(XtaskTrace, self))




# -*- coding: utf-8 -*-

"""Top-level package for OpyenXes."""

__author__ = """Process Mining UC"""
__email__ = 'processmininguc@gmail.com'
__version__ = '0.3.0'

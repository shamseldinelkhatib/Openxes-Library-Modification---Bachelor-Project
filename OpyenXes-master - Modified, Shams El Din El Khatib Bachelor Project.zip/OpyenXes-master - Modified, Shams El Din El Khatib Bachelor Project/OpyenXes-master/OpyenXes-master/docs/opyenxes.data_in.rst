opyenxes.data_in package
========================

Submodules
----------

opyenxes.data_in.XMxmlGZIPParser module
---------------------------------------

.. automodule:: opyenxes.data_in.XMxmlGZIPParser
    :members:
    :undoc-members:
    :show-inheritance:

opyenxes.data_in.XMxmlParser module
-----------------------------------

.. automodule:: opyenxes.data_in.XMxmlParser
    :members:
    :undoc-members:
    :show-inheritance:

opyenxes.data_in.XParserRegistry module
---------------------------------------

.. automodule:: opyenxes.data_in.XParserRegistry
    :members:
    :undoc-members:
    :show-inheritance:

opyenxes.data_in.XUniversalParser module
----------------------------------------

.. automodule:: opyenxes.data_in.XUniversalParser
    :members:
    :undoc-members:
    :show-inheritance:

opyenxes.data_in.XesXmlGZIPParser module
----------------------------------------

.. automodule:: opyenxes.data_in.XesXmlGZIPParser
    :members:
    :undoc-members:
    :show-inheritance:

opyenxes.data_in.XesXmlParser module
------------------------------------

.. automodule:: opyenxes.data_in.XesXmlParser
    :members:
    :undoc-members:
    :show-inheritance:


Module contents
---------------

.. automodule:: opyenxes.data_in
    :members:
    :undoc-members:
    :show-inheritance:

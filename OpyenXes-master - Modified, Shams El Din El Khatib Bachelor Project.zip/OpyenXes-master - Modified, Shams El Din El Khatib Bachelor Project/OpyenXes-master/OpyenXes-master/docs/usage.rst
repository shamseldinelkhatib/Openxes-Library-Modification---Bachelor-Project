=====
Usage
=====

To use OpyenXes in a project::

    import opyenxes

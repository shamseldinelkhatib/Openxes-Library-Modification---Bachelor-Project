opyenxes.extension.std package
==============================

Submodules
----------

opyenxes.extension.std.XAbstractNestedAttributeSupport module
-------------------------------------------------------------

.. automodule:: opyenxes.extension.std.XAbstractNestedAttributeSupport
    :members:
    :undoc-members:
    :show-inheritance:

opyenxes.extension.std.XConceptExtension module
-----------------------------------------------

.. automodule:: opyenxes.extension.std.XConceptExtension
    :members:
    :undoc-members:
    :show-inheritance:

opyenxes.extension.std.XCostExtension module
--------------------------------------------

.. automodule:: opyenxes.extension.std.XCostExtension
    :members:
    :undoc-members:
    :show-inheritance:

opyenxes.extension.std.XExtendedEvent module
--------------------------------------------

.. automodule:: opyenxes.extension.std.XExtendedEvent
    :members:
    :undoc-members:
    :show-inheritance:

opyenxes.extension.std.XIdentityExtension module
------------------------------------------------

.. automodule:: opyenxes.extension.std.XIdentityExtension
    :members:
    :undoc-members:
    :show-inheritance:

opyenxes.extension.std.XLifecycleExtension module
-------------------------------------------------

.. automodule:: opyenxes.extension.std.XLifecycleExtension
    :members:
    :undoc-members:
    :show-inheritance:

opyenxes.extension.std.XMicroExtension module
---------------------------------------------

.. automodule:: opyenxes.extension.std.XMicroExtension
    :members:
    :undoc-members:
    :show-inheritance:

opyenxes.extension.std.XOrganizationalExtension module
------------------------------------------------------

.. automodule:: opyenxes.extension.std.XOrganizationalExtension
    :members:
    :undoc-members:
    :show-inheritance:

opyenxes.extension.std.XSemanticExtension module
------------------------------------------------

.. automodule:: opyenxes.extension.std.XSemanticExtension
    :members:
    :undoc-members:
    :show-inheritance:

opyenxes.extension.std.XTimeExtension module
--------------------------------------------

.. automodule:: opyenxes.extension.std.XTimeExtension
    :members:
    :undoc-members:
    :show-inheritance:


Module contents
---------------

.. automodule:: opyenxes.extension.std
    :members:
    :undoc-members:
    :show-inheritance:

opyenxes.id package
===================

Submodules
----------

opyenxes.id.XID module
----------------------

.. automodule:: opyenxes.id.XID
    :members:
    :undoc-members:
    :show-inheritance:

opyenxes.id.XIDFactory module
-----------------------------

.. automodule:: opyenxes.id.XIDFactory
    :members:
    :undoc-members:
    :show-inheritance:


Module contents
---------------

.. automodule:: opyenxes.id
    :members:
    :undoc-members:
    :show-inheritance:
